import 'package:spotify_sdk/spotify_sdk.dart';
import 'package:flutter/material.dart';
import 'test.dart';


class AuthScreenSpotify extends StatefulWidget {
  @override
  _AuthScreenSpotifyState createState() => _AuthScreenSpotifyState();
}

class _AuthScreenSpotifyState extends State<AuthScreenSpotify> {
  bool _isConnected = false;

  // Fonction pour se connecter à Spotify
  Future<void> signInWithSpotify() async {
    try {
      var result = await SpotifySdk.connectToSpotifyRemote(
        clientId: "a7b5e05f42494a128b43b2d94779245c",
        redirectUrl: "mood://spotify/callback",
      );

      if (result) {
        setState(() {
          _isConnected = true;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Connexion réussie à Spotify !')),
        );

        // Redirection vers la page d'accueil après connexion
    /*    Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => HomeScreen()),
        );*/
        Navigator.pushReplacementNamed(context, '/test');
      }
    } catch (e) {
      print("Erreur d'authentification Spotify : $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erreur de connexion à Spotify.')),
      );
    }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Connexion à Spotify')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Connectez-vous avec Spotify pour accéder aux playlists adaptées à votre humeur.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: signInWithSpotify,
              child: Text(_isConnected ? 'Connecté à Spotify' : 'Se connecter avec Spotify'),
            ),
          ],
        ),
      ),
    );
  }
}







