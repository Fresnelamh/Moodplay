import 'package:flutter/material.dart';
import 'package:crypto/crypto.dart';
import 'dart:convert';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthScreengit extends StatefulWidget {
  @override
  _AuthScreengitState createState() => _AuthScreengitState();
}

class _AuthScreengitState extends State<AuthScreengit> {
  final supabase = Supabase.instance.client;

  // Fonction pour l'authentification avec GitLab
  Future<void> signInWithGitLab() async {
    try {
      // Tentative d'authentification via OAuth avec GitLab
      final result = await supabase.auth.signInWithOAuth(Provider.gitlab);
      final user = supabase.auth.currentUser;
redirectTo:'2ddc9896c549f35559e2647560b9840c8676d09854f3f950c6f73171a2a3524c://login-callback/auth/v1/callback';
      if (user != null) {
        // Redirige vers la page d'accueil après la connexion réussie
        Navigator.pushReplacementNamed(context, '/home');
      }
    } catch (e) {
      // Gestion des erreurs d'authentification
      print("Erreur d'authentification : $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erreur de connexion avec GitLab.')),
      );
    }
  }

  @override
  void initState() {
    super.initState();
    // Écouter les changements d'authentification
    supabase.auth.onAuthStateChange.listen((data) {
      final AuthChangeEvent event = data.event;
      if (event == AuthChangeEvent.signedIn) {
        // L'utilisateur est connecté, rediriger vers la page d'accueil
        Navigator.pushReplacementNamed(context, '/home');
      }
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Connexion')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: signInWithGitLab,
              child: Text('Sign In with Gitlab'),
            ),
          ],
        ),
      ),
    );
  }
}


