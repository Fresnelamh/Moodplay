import 'package:http/http.dart' as http;
import 'dart:convert';

class SpotifyService {
  // Remplace ces valeurs par tes propres identifiants client
  static const String clientId = "a7b5e05f42494a128b43b2d94779245c";  // Ton Client ID de Spotify
  static const String clientSecret = "bf797b310a8140db964335279e523fb5";  // Ton Client Secret de Spotify
  static String accessToken = "";  // Token d'accès à l'API Spotify

  // Fonction pour obtenir le token d'accès à l'API Spotify
  static Future<void> getAccessToken() async {
    final Uri url = Uri.parse("https://accounts.spotify.com/api/token");
    final String basicAuth =
        'Basic ${base64Encode(utf8.encode('$clientId:$clientSecret'))}';

    // Requête pour obtenir le token d'accès
    final response = await http.post(
      url,
      headers: {
        "Authorization": basicAuth,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: "grant_type=client_credentials",  // Type de grant (client credentials)
    );

    // Vérification si la réponse est correcte
    if (response.statusCode == 200) {
      accessToken = json.decode(response.body)['access_token'];
      print("Token d'accès obtenu: $accessToken");
    } else {
      throw Exception("Erreur lors de l'authentification Spotify");
    }
  }

  // Fonction pour récupérer une playlist selon un genre musical
  static Future<String> getPlaylist(String genre) async {
    if (accessToken.isEmpty) {
      await getAccessToken();  // Si le token est vide, on le récupère.
    }

    final Uri url = Uri.parse(
        "https://api.spotify.com/v1/search?q=$genre&type=playlist&limit=1");  // URL pour rechercher une playlist par genre

    // Requête pour récupérer la playlist
    final response = await http.get(
      url,
      headers: {"Authorization": "Bearer $accessToken"},  // En-tête avec le token d'accès
    );

    // Vérification si la réponse est correcte
    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      final String playlistUrl = data['playlists']['items'][0]['external_urls']['spotify'];
      print("URL de la playlist: $playlistUrl");
      return playlistUrl;  // Retourne l'URL de la playlist Spotify
    } else {
      throw Exception("Impossible de récupérer une playlist Spotify");
    }
  }
}
