import 'package:flutter/material.dart';
import 'package:crypto/crypto.dart';
import 'dart:convert';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthScreen extends StatefulWidget {
  final supabase = Supabase.instance.client;

  Future<void> signInWithGitLab() async {
    try {
      await supabase.auth.signInWithOAuth(Provider.gitlab);
      final user = supabase.auth.currentUser;

      if (user != null) {
        Navigator.pushReplacementNamed(context, '/home');
      } catch (e) {
      print("Erreur d'authentification : $e");
    }
  }





    @override
    Widget build(BuildContext context) {
    return Scaffold(
    appBar: AppBar(title: Text('Connexion')),
    body: Padding(
    padding: EdgeInsets.all(16.0),
    child: Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
    SizedBox(height: 20),
    ElevatedButton(
    onPressed: signInWithGitLab,
    child: Text('Sign In with Gitlab'),
    ),
    ],
    ),
    ),
    );
    }
  }




  class AuthSpotify {
  // Fonction pour authentifier l'utilisateur avec Spotify
  static Future<void> auhentifspotify() async {
  try {
  // Demande l'autorisation à l'utilisateur pour accéder à Spotify
  var authResult = await SpotifySdk.connectToSpotifyRemote(
  clientId: 'a7b5e05f42494a128b43b2d94779245c', // Remplace par ton client ID Spotify
  redirectUrl: 'mood://spotify/callback', // Remplace par ton URI de redirection
  );

  if (authResult != null) {
  print("Connecté à Spotify : ${authResult}");
  } else {
  print("Erreur d'authentification");
  }
  } catch (e) {
  print("Erreur de connexion à Spotify : $e");
  }
  }
  }

