import 'package:http/http.dart' as http;
import 'dart:convert';

class SpotifyService {
  static const String clientId = "a7b5e05f42494a128b43b2d94779245c";
  static const String clientSecret = "bf797b310a8140db964335279e523fb5";
  static String accessToken = "";

  /// Obtenir le token d'accès à l'API Spotify
  static Future<void> getAccessToken() async {
    final Uri url = Uri.parse("https://accounts.spotify.com/api/token");
    final String basicAuth =
        'Basic ${base64Encode(utf8.encode('$clientId:$clientSecret'))}';

    final response = await http.post(
      url,
      headers: {
        "Authorization": basicAuth,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: "grant_type=client_credentials",
    );

    if (response.statusCode == 200) {
      accessToken = json.decode(response.body)['access_token'];
    } else {
      throw Exception("Erreur lors de l'authentification Spotify");
    }
  }

  /// Récupérer une playlist en fonction du genre musical
  static Future<String> getPlaylist(String genre) async {
    if (accessToken.isEmpty) {
      await getAccessToken();
    }

    final Uri url = Uri.parse(
        "https://api.spotify.com/v1/search?q=$genre&type=playlist&limit=1");

    final response = await http.get(
      url,
      headers: {"Authorization": "Bearer $accessToken"},
    );

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      final String playlistUrl = data['playlists']['items'][0]['external_urls']['spotify'];
      return playlistUrl;
    } else {
      throw Exception("Impossible de récupérer une playlist Spotify");
    }
  }
}
