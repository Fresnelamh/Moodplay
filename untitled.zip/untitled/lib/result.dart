import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'spotify_service.dart';

class ResultScreen extends StatefulWidget {
  @override
  _ResultScreenState createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  String detectedMood = "Analyse en cours...";
  String playlistUrl = "";

  /// Associe une humeur à un genre musical
  final Map<String, String> moodToGenre = {
    "Heureux": "happy",
    "Motivé": "workout",
    "Chill": "chill",
    "Triste": "sad",
    "Énergique": "party",
    "Créatif": "lofi",
  };

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final String mood = ModalRoute.of(context)!.settings.arguments as String;
    analyzeMood(mood);
  }

  /// Analyse l'humeur avec Mistral AI
  Future<void> analyzeMood(String text) async {
    const String apiKey = 'VOTRE_CLE_API_MISTRAL';
    const String agentId = 'ag:2883c86c:20250306:moodplay:22d16989';
    final Uri url = Uri.parse('https://api.mistral.ai/v1/agents/$agentId/completions');

    try {
      final response = await http.post(
        url,
        headers: {
          'Authorization': 'Bearer $apiKey',
          'Content-Type': 'application/json',
        },
        body: json.encode({
          'input': text,
          'parameters': {},
        }),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        String moodDetected = data['mood'] ?? "Mood non détecté";

        setState(() {
          detectedMood = moodDetected;
        });

        // Vérifier si l'humeur correspond à un genre Spotify
        if (moodToGenre.containsKey(moodDetected)) {
          fetchSpotifyPlaylist(moodToGenre[moodDetected]!);
        }
      } else {
        setState(() {
          detectedMood = "Erreur : ${response.statusCode}";
        });
      }
    } catch (e) {
      setState(() {
        detectedMood = "Échec de l'analyse";
      });
    }
  }

  /// Récupère une playlist Spotify
  Future<void> fetchSpotifyPlaylist(String genre) async {
    try {
      String url = await SpotifyService.getPlaylist(genre);
      setState(() {
        playlistUrl = url;
      });
    } catch (e) {
      setState(() {
        playlistUrl = "Impossible de récupérer une playlist";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text(
          'Résultat',
          style: GoogleFonts.poppins(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              detectedMood,
              style: GoogleFonts.poppins(fontSize: 20, color: Colors.white),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
            playlistUrl.isNotEmpty
                ? ElevatedButton(
              onPressed: () {
                // Ouvre la playlist Spotify
                launchURL(playlistUrl);
              },
              child: Text("🎵 Écouter la playlist"),
            )
                : CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }
}
