import 'package:flutter/material.dart';
import 'spotifyservice.dart';
import 'package:url_launcher/url_launcher.dart';

class AuthScreen extends StatefulWidget {
  @override

  _AuthScreenState createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  // Fonction pour obtenir la playlist en fonction de l'emoji sélectionné
  void getPlaylistBasedOnMood(String emoji) async {
    String genre = '';

    // Associer des emojis à des genres musicaux
    if (emoji == '😊') {
      genre = 'pop';  // Humeur joyeuse => Pop
    } else if (emoji == '😢') {
      genre = 'Latino'; // Humeur triste => Jazz
    } else if (emoji == '😡') {
      genre = 'Metal'; // Humeur en colère => Rock
    } else if (emoji == '😴') {
      genre = 'chill'; // Humeur calme => Chill
    }

    try {
      String playlistUrl = await SpotifyService.getPlaylist(genre);
      print('Voici la playlist: $playlistUrl');
      // Ouvre la playlist Spotify
      // Tu peux rediriger l'utilisateur vers cette URL dans un navigateur ou dans l'application Spotify
      _openSpotifyPlaylist(playlistUrl);
    } catch (e) {
      print("Erreur: $e");

    }
  }

  // Fonction pour ouvrir la playlist Spotify dans un navigateur ou l'application
  void _openSpotifyPlaylist(String playlistUrl) async {
    final Uri url = Uri.parse(playlistUrl);
    if (await canLaunchUrl(url)) {
      await launchUrl(url);
    } else {
      print('Impossible d\'ouvrir l\'URL: $playlistUrl');
      // Gérer l'erreur, par exemple afficher un message à l'utilisateur
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Impossible d\'ouvrir la playlist.')),
      );
    }
    // Tu peux utiliser un package comme `url_launcher` pour ouvrir l'URL dans un navigateur ou l'application Spotify
    // url_launcher: ^6.0.10
    // Voici un exemple de code pour l'utiliser :

    // await launch(playlistUrl); // Si tu veux ouvrir dans le navigateur
  }


  /*

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Choisissez votre humeur')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 20),
            Text('Comment vous sentez-vous ?'),
            SizedBox(height: 20),
            // Boutons avec emojis
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  icon: Text('😊'),
                  onPressed: () {
                    getPlaylistBasedOnMood('😊');
                  },
                ),
                IconButton(
                  icon: Text('😢'),
                  onPressed: () {
                    getPlaylistBasedOnMood('😢');
                  },
                ),
                IconButton(
                  icon: Text('😡'),
                  onPressed: () {
                    getPlaylistBasedOnMood('😡');
                  },
                ),
                IconButton(
                  icon: Text('😴'),
                  onPressed: () {
                    getPlaylistBasedOnMood('😴');
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
*/


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black, // Fond noir pour une belle ambiance
      appBar: AppBar(
        title: Text('Moodplay', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.black, // Fond noir de l'app bar
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'How do you feel today?',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 40), // Espacement entre le texte et les emojis
            // Ligne d'emojis avec leurs descriptions
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildEmojiButton('😊', 'Happy','Heureux'),
                SizedBox(width: 20),
                _buildEmojiButton('😢', 'Sad','Triste'),
                SizedBox(width: 20),
                _buildEmojiButton('😡', 'Angry','En colère'),
                SizedBox(width: 20),
                _buildEmojiButton('😴', 'Relaxed', 'Calme'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // Fonction pour construire chaque bouton emoji avec effet de clic et description en dessous
  Widget _buildEmojiButton(String emoji, String mood, String genre) {
    return GestureDetector(
      onTap: () {
        getPlaylistBasedOnMood(emoji); // Appeler la fonction avec l'emoji sélectionné
      },
      child: Column(
        children: [
          AnimatedContainer(
            duration: Duration(milliseconds: 200), // Effet animé au clic
            height: 80, // Hauteur du carré
            width: 80,  // Largeur du carré
            decoration: BoxDecoration(
              color: Colors.grey[800], // Fond du carré
              borderRadius: BorderRadius.circular(12), // Coins arrondis
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.5), // Ombre discrète
                  spreadRadius: 3,
                  blurRadius: 5,
                  offset: Offset(0, 3), // Ombre en bas
                ),
              ],
            ),
            child: Center(
              child: Text(
                emoji,
                style: TextStyle(
                  fontSize: 36,  // Taille de l'emoji
                  color: Colors.white, // Couleur de l'emoji
                ),
              ),
            ),
          ),
          SizedBox(height: 10),
          Text(
            '$mood', // Texte sous l'emoji pour décrire l'humeur
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
            ),
          ),
          Text(
            '$genre', // Genre musical associé
            style: TextStyle(
              color: Colors.white70,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }
}