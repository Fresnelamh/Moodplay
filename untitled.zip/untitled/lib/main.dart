import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:untitled/spotifyauth.dart';
import 'interfacespotify.dart';
import 'spotifyservice.dart';



import 'auth_screen.dart'; // Import de la page d'authentification
import 'test.dart';

void main() async {
  // Permet d'attendre les services avant de lancer l'app
  WidgetsFlutterBinding.ensureInitialized();

  // Initialisation de Supabase avec l'URL et la clé directement
  await Supabase.initialize(
    url:  "https://rsxdzrdhobcufzpqnpgc.supabase.co", // Mets ton URL Supabase
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJzeGR6cmRob2JjdWZ6cHFucGdjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDA1Nzc1NDEsImV4cCI6MjA1NjE1MzU0MX0.mFo5CvnZLibsbfNon3tFR2gSgrYpVUs0-uTZcwcOD6M', // Mets ta clé API
  );

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Connexion App',
      initialRoute: '/',
      routes: {
        '/': (context) => AuthScreengit(), // Page d'authentification
       // '/': (context) => AuthScreenSpotify(), // Page d'authentification
       '/home': (context) => AuthScreen(), // Page Chronomètre après connexion
      },
    );
  }
}
/*
class StopwatchScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Chronomètre')),
      body: Center(
        child: Text(
          'Bienvenue Toto 🎯',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}
*/