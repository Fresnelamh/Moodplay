package fr.angers.example.untitled;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
