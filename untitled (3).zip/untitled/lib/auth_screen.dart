import 'package:flutter/material.dart';
import 'package:crypto/crypto.dart';
import 'dart:convert';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthScreen extends StatefulWidget {
  @override
  _AuthScreenState createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final supabase = Supabase.instance.client;

  // Fonction pour l'authentification avec GitLab
  Future<void> signInWithGitLab() async {
    try {
      // Tentative d'authentification via OAuth avec GitLab
      await supabase.auth.signInWithOAuth(Provider.gitlab);
      final user = supabase.auth.currentUser;

      if (user != null) {
        // Redirige vers la page d'accueil après la connexion réussie
        Navigator.pushReplacementNamed(context, '/home');
      }
    } catch (e) {
      // Gestion des erreurs d'authentification
      print("Erreur d'authentification : $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erreur de connexion avec GitLab.')),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Connexion')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: signInWithGitLab,
              child: Text('Sign In with Gitlab'),
            ),
          ],
        ),
      ),
    );
  }
}


